// ============================================================================
//  MINECRAFT FOOTBALL 1.0  -  Minecraft Bedrock 1.26.60  (@minecraft/server 2.11.0, API estável)
//  Toda a lógica (física, posse, chute, roubo) roda no servidor; a bola é UMA entidade
//  compartilhada, então todos os jogadores veem a mesma posição, posse, chutes e roubos.
// ============================================================================
import { world, system, DisplaySlotId, ObjectiveSortOrder } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";

// ============================== CONFIGURAÇÕES ===============================
// Velocidades em BLOCOS POR TICK (0.05 = 1 bloco/s; 1.0 = 20 blocos/s).
const CONFIG = {
  // ---- Chute ----
  KICK_MIN_SPEED: 0.28,          // velocidade mínima do chute (jogador parado)
  KICK_MAX_SPEED: 1.0,           // velocidade máxima do chute (sprint + pulo)
  KICK_FORCE_MULTIPLIER: 1.0,    // multiplicador geral de força
  KICK_HEIGHT_SENSITIVITY: 1.0,  // sensibilidade da altura (1.5 = chutes mais altos, 0.5 = mais baixos)
  KICK_PICKUP_DELAY: 14,         // ticks em que quem chutou não pode dominar a bola de novo
  // Velocidade do jogador (blocos/s) -> fração da força [0..1]:
  // parado=fraco | andando(4.3)=moderado | correndo(5.6)=forte | correndo+pulo(7.2)=muito forte
  KICK_FORCE_CURVE: [[0, 0], [0.6, 0.05], [4.3, 0.45], [5.6, 0.75], [7.2, 1]],
  // Inclinação da câmera (graus acima do horizonte; negativo = olhando para baixo)
  // -> elevação do chute em graus: rasteiro / baixo / normal / alto / muito alto
  KICK_ELEVATION_CURVE: [[-90, 0], [-35, 0], [-18, 6], [0, 15], [30, 38], [60, 62], [90, 78]],

  // ---- Física da bola ----
  GRAVITY: 0.04,                 // gravidade (blocos/tick²)
  AIR_DRAG: 0.996,               // resistência do ar por tick
  GROUND_FRICTION: 0.975,        // atrito ao rolar no chão (por tick)
  GROUND_STOP_DECEL: 0.0012,     // desaceleração extra para a bola parar de vez
  BOUNCE_STRENGTH: 0.62,         // força das quicadas (0..1)
  BOUNCE_MIN_IMPACT: 0.10,       // abaixo disso a bola não quica, só rola
  BOUNCE_HORIZONTAL_KEEP: 0.94,  // velocidade horizontal mantida a cada quicada
  WALL_BOUNCE: 0.70,             // força do rebote em paredes/traves
  MAX_BALL_SPEED: 1.05,          // limite máximo de velocidade (evita bugs)

  // ---- Posse / condução ----
  DRIBBLE_DISTANCE: 1.0,         // distância da bola em relação ao jogador (sempre à frente, visível)
  DRIBBLE_FOLLOW: 0.7,           // 0..1  (1 = cola no alvo, menor = mais suave)
  DIRECTION_SMOOTH: 0.3,         // suavização da direção da bola
  DIRECTION_MIN_MOVE: 0.03,      // blocos/tick mínimos para usar a direção do movimento
  // Domínio: a bola encostou em QUALQUER parte da hitbox do jogador (pés, corpo ou cabeça) = domina.
  DIRECT_KICK_MAX_BALL_SPEED: 0.06, // bola "parada no chão" (velocidade máx.) para valer o chute direto
  PICKUP_PROTECT: 10,            // ticks de proteção logo após dominar

  // ---- Lateral (agachar pega a bola na mão; agachar de novo arremessa) ----
  THROW_SPEED: 0.5,              // velocidade do arremesso (blocos/tick)
  THROW_MIN_ELEVATION: 20,       // ângulo mínimo do arremesso (graus)
  HOLD_HEIGHT: 1.95,             // altura da bola nas mãos (acima dos pés)

  // ---- Roubo de bola ----
  // Roubo = outro jogador (ou goleiro) ENCOSTAR na bola que está nos pés de quem a conduz.
  STEAL_PROTECT: 20,             // proteção após um roubo/domínio (ticks; 20 = 1 s) - evita "pinga-pinga"

  // ---- Gol ----
  GOAL_COOLDOWN: 60,             // ticks até a mesma bola poder marcar outro gol (60 = 3 s)

  // ---- Goleiro (quanto maior, mais fácil de defender) ----
  KEEPER_REACH_H: 1.6,           // alcance horizontal (blocos) ao redor do goleiro
  KEEPER_REACH_UP: 2.9,          // alcance para cima, acima dos pés (mãos esticadas)
  KEEPER_REACH_DOWN: 0.7,        // alcance para baixo, abaixo dos pés

  // ---- Goleiro (mob) ----
  MK_SPEED: 0.09,                // velocidade lateral PADRÃO (blocos/tick; 0.09 = 1,8 blocos/s) - ajustável no menu
  MK_REACH_H: 1.4,               // alcance horizontal para tocar na bola (hitbox da bola)
  MK_REACH_UP: 2.6,              // altura máxima (acima dos pés) para tocar na bola
  MK_FOOT_HEIGHT: 0.8,           // bola abaixo disso (acima dos pés) = tocou no PÉ; acima = PEITO
  MK_HOLD_TICKS: 60,             // tempo segurando a bola antes de jogar (60 = 3 s)
  MK_HOLD_FORWARD: 0.65,         // distância da bola na mão, à frente do goleiro
  MK_HOLD_HEIGHT: 1.4,           // altura da bola na mão (acima dos pés)
  MK_THROW_POWER_MIN: 0.55,      // força aleatória do arremesso (mín/máx; limite do jogo = MAX_BALL_SPEED)
  MK_THROW_POWER_MAX: 1.0,
  MK_FOOT_POWER_MIN: 0.8,        // força aleatória do chute direto (toque no pé)
  MK_FOOT_POWER_MAX: 1.0,
  MK_ELEV_MIN: 15,               // ângulo aleatório de saída (graus acima do horizonte)
  MK_ELEV_MAX: 50,
  MK_SPREAD: 30,                 // desvio lateral aleatório (graus para cada lado, sempre pra frente)
  MK_IGNORE_TICKS: 30,           // tempo que o goleiro ignora a bola que acabou de jogar

  SOUNDS: true,
};
// ===========================================================================

const C = CONFIG;
const DEG = Math.PI / 180;
const BALL_TYPE = "football:ball";
const R = 0.25;       // raio da bola (modelo de 0,5 bloco)
const EPS = 0.001;

const balls = new Map();    // id da entidade -> estado da bola
const players = new Map();  // id do jogador  -> estado do jogador
let playerById = new Map();
let blockCache = new Map();
let tick = 0;
const loggedErrors = new Set();

const clamp = (v, lo, hi) => (v < lo ? lo : v > hi ? hi : v);

function curve(nodes, x) {
  if (x <= nodes[0][0]) return nodes[0][1];
  for (let i = 1; i < nodes.length; i++) {
    if (x <= nodes[i][0]) {
      const [x0, y0] = nodes[i - 1];
      const [x1, y1] = nodes[i];
      return y0 + ((y1 - y0) * (x - x0)) / (x1 - x0);
    }
  }
  return nodes[nodes.length - 1][1];
}

function isValid(e) {
  try {
    const v = e.isValid;
    return typeof v === "function" ? v.call(e) : v !== false;
  } catch {
    return false;
  }
}

function logOnce(err) {
  const msg = String(err && err.stack ? err.stack : err);
  if (!loggedErrors.has(msg)) {
    loggedErrors.add(msg);
    console.warn("[Football] " + msg);
  }
}

// ------------------------------- Blocos -----------------------------------
// Blocos "passáveis" (plantas, tochas, placas...) que a bola atravessa.
const PASSABLE = /(air|tallgrass|short_grass|tall_grass|fern|flower|poppy|dandelion|torch|sapling|vine|carpet|sign|rail|button|pressure_plate|deadbush|snow_layer|web|ladder|lever|redstone_wire|double_plant|seagrass|kelp|mushroom|fire|lantern_hanging|banner|out_of_bounds)/;
function blockIsSolid(block) {
  let air = false, liquid = false;
  try { air = block.isAir === true || (typeof block.isAir === "function" && block.isAir()); } catch {}
  try { liquid = block.isLiquid === true || (typeof block.isLiquid === "function" && block.isLiquid()); } catch {}
  if (air || liquid) return false;
  return !PASSABLE.test(String(block.typeId));   // todo o resto conta como bloco sólido
}

function solidAt(dim, x, y, z) {
  if (y < -64 || y > 319) return false;
  const key = dim.id + "|" + x + "|" + y + "|" + z;
  let v = blockCache.get(key);
  if (v !== undefined) return v;
  try {
    const block = dim.getBlock({ x, y, z });
    v = block ? blockIsSolid(block) : true; // chunk não carregado = sólido
  } catch {
    v = true;
  }
  blockCache.set(key, v);
  return v;
}

function collides(dim, cx, cy, cz) {
  const x0 = Math.floor(cx - R), x1 = Math.floor(cx + R - 1e-7);
  const y0 = Math.floor(cy - R), y1 = Math.floor(cy + R - 1e-7);
  const z0 = Math.floor(cz - R), z1 = Math.floor(cz + R - 1e-7);
  for (let x = x0; x <= x1; x++)
    for (let y = y0; y <= y1; y++)
      for (let z = z0; z <= z1; z++)
        if (solidAt(dim, x, y, z)) return true;
  return false;
}

// Move a bola em um eixo; se bater, encosta na face do bloco e retorna true.
function moveAxis(dim, b, axis, d) {
  if (d === 0) return false;
  const old = b[axis];
  b[axis] = old + d;
  if (!collides(dim, b.x, b.y, b.z)) return false;
  const edge = d > 0 ? b[axis] + R : b[axis] - R;
  const cell = Math.floor(edge);
  b[axis] = d > 0 ? cell - R - EPS : cell + 1 + R + EPS;
  if ((d > 0 && b[axis] < old) || (d < 0 && b[axis] > old) || collides(dim, b.x, b.y, b.z)) b[axis] = old;
  return true;
}

// ------------------------------ Som ---------------------------------------
function sound(dim, x, y, z, id, vol, pitch) {
  if (!C.SOUNDS) return;
  try {
    for (const p of dim.getPlayers({ location: { x, y, z }, maxDistance: 32 })) {
      p.playSound(id, { location: { x, y, z }, volume: vol, pitch });
    }
  } catch {}
}

// --------------------------- Estado dos jogadores -------------------------
function updatePlayers(list) {
  playerById = new Map();
  for (const p of list) {
    let loc, dimId;
    try {
      loc = p.location;
      dimId = p.dimension.id;
    } catch {
      continue;
    }
    playerById.set(p.id, p);
    let s = players.get(p.id);
    if (!s) {
      s = { x: loc.x, y: loc.y, z: loc.z, dim: dimId, avx: 0, avz: 0, speed: 0,
            onGround: true, jumping: false, kick: false, inactive: false, sneaking: false, sneakEdge: false, keeper: false };
      players.set(p.id, s);
    }
    let dx = loc.x - s.x, dy = loc.y - s.y, dz = loc.z - s.z;
    if (s.dim !== dimId || Math.abs(dx) > 4 || Math.abs(dz) > 4 || Math.abs(dy) > 6) {
      dx = dy = dz = 0;
      s.avx = s.avz = 0;
    }
    // média móvel: suaviza o "tremido" de posição dos clientes mobile
    s.avx = s.avx * 0.5 + dx * 0.5;
    s.avz = s.avz * 0.5 + dz * 0.5;
    s.speed = Math.hypot(s.avx, s.avz); // blocos/tick

    let onGround = true, jumping = false;
    try { onGround = p.isOnGround; jumping = p.isJumping === true; } catch {}
    // Início de pulo: saiu do chão subindo, ou apertou o botão de pulo no chão.
    s.kick = (s.onGround && !onGround && dy > 0.12) || (jumping && !s.jumping && (s.onGround || onGround));

    let sneaking = false;
    try { sneaking = p.isSneaking === true; } catch {}
    s.sneakEdge = sneaking && !s.sneaking;   // começou a agachar neste tick
    s.sneaking = sneaking;

    if (tick % 5 === 0 || s.keeperChecked !== true) { s.keeper = isKeeper(p); s.keeperChecked = true; }

    let inactive = false;
    try {
      const gm = typeof p.getGameMode === "function" ? p.getGameMode() : undefined;
      if (gm !== undefined && String(gm).toLowerCase() === "spectator") inactive = true;
    } catch {}
    try {
      const h = p.getComponent("minecraft:health");
      if (h && h.currentValue <= 0) inactive = true;
    } catch {}

    s.x = loc.x; s.y = loc.y; s.z = loc.z; s.dim = dimId;
    s.onGround = onGround; s.jumping = jumping; s.inactive = inactive;
  }
}

// Goleiro = quem está de capacete de couro.
function isKeeper(p) {
  try {
    const eq = p.getComponent("minecraft:equippable");
    const it = eq ? eq.getEquipment("Head") : undefined;
    return !!it && it.typeId === "minecraft:leather_helmet";
  } catch {
    return false;
  }
}

// ------------------------------ Bolas -------------------------------------
function registerBall(e) {
  if (balls.has(e.id)) return balls.get(e.id);
  const loc = e.location;
  let yaw = 0;
  try { yaw = e.getRotation().y; } catch {}
  const b = {
    id: e.id, entity: e, dim: e.dimension,
    x: loc.x, y: loc.y + R, z: loc.z, vx: 0, vy: 0, vz: 0,
    ownerId: null, dirx: 0, dirz: 1, yaw,
    protectUntil: 0, noPickup: {}, resting: false, held: false, px: loc.x, py: loc.y + R, pz: loc.z,
    safe: { x: loc.x, y: loc.y + R, z: loc.z }, dirty: true, goalCooldown: 0, lastPlayer: null, outCooldown: 0, mk: null, clearOf: null,
  };
  balls.set(e.id, b);
  colorNewBall(e);
  return b;
}

function scanBalls() {
  const dims = new Map();
  for (const p of playerById.values()) {
    try { dims.set(p.dimension.id, p.dimension); } catch {}
  }
  for (const d of dims.values()) {
    try {
      for (const e of d.getEntities({ type: BALL_TYPE })) registerBall(e);
    } catch (err) { logOnce(err); }
  }
}

function setOwnerTag(b, text) {
  try { b.entity.nameTag = text; } catch {}
}

function release(b) {
  b.ownerId = null;
  b.held = false;
  setOwnerTag(b, "");
}

function takeBall(b, p, ps) {
  b.ownerId = p.id;
  b.held = false;
  b.protectUntil = tick + C.PICKUP_PROTECT;
  b.vx = b.vy = b.vz = 0;
  b.resting = false;
  setOwnerTag(b, "§e⚽ §f" + p.name);
  try { p.onScreenDisplay.setActionBar("§a⚽ Você está com a bola! §7Pule para chutar."); } catch {}
  dribble(b, p, ps, true);
}

// Bola acompanha os pés do jogador, ligeiramente à frente, na direção do movimento.
function dribble(b, p, ps, snap) {
  const yaw = p.getRotation().y * DEG;   // sempre à frente de onde o jogador olha
  const tx = -Math.sin(yaw), tz = Math.cos(yaw);
  if (snap) {
    b.dirx = tx; b.dirz = tz;
  } else {
    b.dirx += (tx - b.dirx) * C.DIRECTION_SMOOTH;
    b.dirz += (tz - b.dirz) * C.DIRECTION_SMOOTH;
    const l = Math.hypot(b.dirx, b.dirz);
    if (l < 0.2) { b.dirx = tx; b.dirz = tz; } else { b.dirx /= l; b.dirz /= l; }
  }
  const D = C.DRIBBLE_DISTANCE;
  const ny = ps.y + R + 0.01;
  let nx = ps.x + b.dirx * D, nz = ps.z + b.dirz * D;
  if (collides(b.dim, nx, ny, nz)) {          // parede à frente: aproxima, mas nunca para dentro do jogador
    let ok = false;
    for (const f of [0.75, 0.55]) {
      const tx2 = ps.x + b.dirx * D * f, tz2 = ps.z + b.dirz * D * f;
      if (!collides(b.dim, tx2, ny, tz2)) { nx = tx2; nz = tz2; ok = true; break; }
    }
    if (!ok) { nx = ps.x + b.dirx * D * 0.5; nz = ps.z + b.dirz * D * 0.5; }
  }
  const ox = b.x, oy = b.y, oz = b.z;
  if (snap || Math.hypot(nx - b.x, nz - b.z) > 2.5 || Math.abs(ny - b.y) > 2) {
    b.x = nx; b.y = ny; b.z = nz;
  } else {
    b.x += (nx - b.x) * C.DRIBBLE_FOLLOW;
    b.z += (nz - b.z) * C.DRIBBLE_FOLLOW;
    b.y = ny;
  }
  b.vx = b.x - ox; b.vy = b.y - oy; b.vz = b.z - oz;
  b.yaw = Math.atan2(-b.dirx, b.dirz) / DEG;
  b.dirty = true;
}

// Pega a bola na mão (por toque/hit ou goleiro).
function grabToHand(b, p, ps, silent) {
  b.ownerId = p.id;
  b.held = true;
  b.protectUntil = tick + C.PICKUP_PROTECT;
  b.resting = false;
  setOwnerTag(b, "§e⚽ §f" + p.name);
  if (!silent) { try { world.sendMessage("§e⚽ " + p.name + " pegou a bola na mão"); } catch {} }
  try {
    p.onScreenDisplay.setActionBar(ps.keeper
      ? "§e🧤 Bola na mão! §7Agache: soltar no chão | Pule: chutar"
      : "§e⚽ Bola na mão! §7Toque num bloco: colocar | Agache: arremessar");
  } catch {}
  hold(b, p, ps);
}

// A bola (trajetória do último tick até agora) encostou na hitbox do jogador?
function touchesHitbox(b, ps) {
  const dx = b.x - b.px, dy = b.y - b.py, dz = b.z - b.pz;
  const n = Math.max(1, Math.ceil(Math.hypot(dx, dy, dz) / 0.2));
  for (let i = 1; i <= n; i++) {
    const t = i / n, x = b.px + dx * t, y = b.py + dy * t, z = b.pz + dz * t;
    if (Math.abs(x - ps.x) <= 0.3 + R && Math.abs(z - ps.z) <= 0.3 + R &&
        y >= ps.y - R && y <= ps.y + 1.8 + R) return true;
  }
  return false;
}

// Alcance ampliado do goleiro: a trajetória da bola passou perto dele (defesa).
function touchesKeeper(b, ps) {
  const dx = b.x - b.px, dy = b.y - b.py, dz = b.z - b.pz;
  const n = Math.max(1, Math.ceil(Math.hypot(dx, dy, dz) / 0.2));
  for (let i = 1; i <= n; i++) {
    const t = i / n, x = b.px + dx * t, y = b.py + dy * t, z = b.pz + dz * t;
    if (Math.abs(x - ps.x) <= C.KEEPER_REACH_H && Math.abs(z - ps.z) <= C.KEEPER_REACH_H &&
        y >= ps.y - C.KEEPER_REACH_DOWN && y <= ps.y + C.KEEPER_REACH_UP) return true;
  }
  return false;
}

// Coloca a bola no chão onde o jogador clicou (bola na mão).
const FACE = { Up: [0, 1, 0], Down: [0, -1, 0], North: [0, 0, -1], South: [0, 0, 1], East: [1, 0, 0], West: [-1, 0, 0] };
function heldBallOf(p) {
  for (const b of balls.values()) if (b.ownerId === p.id && b.held) return b;
  return null;
}

// Solta a bola da mão em (x,y,z). Quem soltou só domina de novo depois de sair de cima da bola.
function dropHeldAt(p, ball, x, y, z) {
  for (let i = 0; i < 3 && collides(ball.dim, x, y, z); i++) y += 1;   // espaço ocupado: sobe
  release(ball);
  ball.x = x; ball.y = y; ball.z = z;
  ball.px = x; ball.py = y; ball.pz = z;
  ball.vx = ball.vy = ball.vz = 0;
  ball.resting = false;
  ball.noPickup[p.id] = tick + 15;
  ball.clearOf = p.id;
  ball.dirty = true;
  sound(ball.dim, x, y, z, "random.pop", 0.5, 0.8);
}

// Coloca a bola no ponto exato clicado (faceLoc) de uma face de bloco.
function placeHeld(p, block, face, faceLoc) {
  const ball = heldBallOf(p);
  if (!ball || !block) return;
  const ps = players.get(p.id);
  const bl = block.location;
  const f = FACE[String(face)] || FACE.Up;
  let x, y, z;
  if (faceLoc) {
    const o = R + 0.02;
    x = faceLoc.x + f[0] * o; y = faceLoc.y + f[1] * o; z = faceLoc.z + f[2] * o;
    if (f[1] === 0) y = Math.max(y, bl.y + R + 0.02);                // lateral: nunca abaixo do chão do bloco
  } else {
    x = bl.x + f[0] + 0.5; y = bl.y + f[1] + R + 0.02; z = bl.z + f[2] + 0.5;
  }
  if (ps && Math.hypot(x - ps.x, z - ps.z) > 8) return;              // longe demais
  dropHeldAt(p, ball, x, y, z);
}

// Sem bloco na mira (céu/longe): coloca no chão, um passo à frente do jogador.
function placeHeldAhead(p) {
  const ball = heldBallOf(p), ps = players.get(p.id);
  if (!ball || !ps) return;
  const yaw = p.getRotation().y * DEG;
  const y = ps.y + R + 0.02;
  let x = 0, z = 0;
  for (const d of [1.15, 0.9, 0.7]) {
    x = ps.x - Math.sin(yaw) * d; z = ps.z + Math.cos(yaw) * d;
    if (!collides(ball.dim, x, y, z)) break;
  }
  dropHeldAt(p, ball, x, y, z);
}

// Coloca a bola onde o jogador está MIRANDO (ignora a própria bola na frente da câmera).
function placeHeldAtView(p, fbBlock, fbFace) {
  if (!heldBallOf(p)) return;
  let hit = null;
  try { hit = p.getBlockFromViewDirection({ maxDistance: 6 }); } catch {}
  if (hit && hit.block) { placeHeld(p, hit.block, hit.face, hit.faceLocation); return; }
  if (fbBlock) { placeHeld(p, fbBlock, fbFace); return; }
  placeHeldAhead(p);
}

// ------------------------- Lateral: bola na mão ---------------------------
function hold(b, p, ps) {
  const yaw = p.getRotation().y * DEG;
  b.dirx = -Math.sin(yaw); b.dirz = Math.cos(yaw);
  let nx = ps.x + b.dirx * 0.25, nz = ps.z + b.dirz * 0.25, ny = ps.y + C.HOLD_HEIGHT;
  if (collides(b.dim, nx, ny, nz)) ny = ps.y + 1.5;           // teto baixo: segura mais baixo
  b.x = nx; b.y = ny; b.z = nz;
  b.vx = b.vy = b.vz = 0;
  b.yaw = Math.atan2(-b.dirx, b.dirz) / DEG;
  b.dirty = true;
}

function throwIn(b, p, ps) {
  const rot = p.getRotation();
  const yaw = rot.y * DEG;
  const elev = clamp(curve(C.KICK_ELEVATION_CURVE, -rot.x) + C.THROW_MIN_ELEVATION, C.THROW_MIN_ELEVATION, 75) * DEG;
  const power = clamp(C.THROW_SPEED + ps.speed * 0.5, 0.2, C.MAX_BALL_SPEED);
  b.vx = -Math.sin(yaw) * Math.cos(elev) * power;
  b.vz = Math.cos(yaw) * Math.cos(elev) * power;
  b.vy = Math.sin(elev) * power;
  b.noPickup[p.id] = tick + C.KICK_PICKUP_DELAY;
  b.resting = false;
  b.yaw = Math.atan2(b.vx === 0 && b.vz === 0 ? 0 : -b.vx, b.vz) / DEG;
  b.dirty = true;
  release(b);
  sound(b.dim, b.x, b.y, b.z, "random.pop", 0.6, 0.9);
}

// ---------------------------------- Chute ---------------------------------
function kick(b, p, ps) {
  const rot = p.getRotation();             // x = pitch (+ para baixo), y = yaw
  const yaw = rot.y * DEG;
  const up = -rot.x;                       // graus acima do horizonte
  const elev = clamp(curve(C.KICK_ELEVATION_CURVE, up) * C.KICK_HEIGHT_SENSITIVITY, 0, 85) * DEG;
  const force = curve(C.KICK_FORCE_CURVE, ps.speed * 20);
  let power = (C.KICK_MIN_SPEED + (C.KICK_MAX_SPEED - C.KICK_MIN_SPEED) * force) * C.KICK_FORCE_MULTIPLIER;
  power = clamp(power, 0.05, C.MAX_BALL_SPEED);

  const hx = -Math.sin(yaw), hz = Math.cos(yaw);
  b.vx = hx * Math.cos(elev) * power;
  b.vz = hz * Math.cos(elev) * power;
  b.vy = Math.sin(elev) * power;

  // garante que a bola saia da frente do jogador
  const ahead = (b.x - ps.x) * hx + (b.z - ps.z) * hz;
  if (ahead < 0.6) {
    const nx = ps.x + hx * 0.7, nz = ps.z + hz * 0.7;
    if (!collides(b.dim, nx, b.y, nz)) { b.x = nx; b.z = nz; }
  }
  b.noPickup[p.id] = tick + C.KICK_PICKUP_DELAY;
  b.resting = false;
  b.yaw = Math.atan2(-hx, hz) / DEG;
  b.dirty = true;
  release(b);
  sound(b.dim, b.x, b.y, b.z, "random.pop", 0.6 + 0.4 * (power / C.MAX_BALL_SPEED), 0.6 + 0.5 * (power / C.MAX_BALL_SPEED));
}

// ---------------------------------- Roubo ---------------------------------
// Qualquer outro jogador que ENCOSTE na bola (passar por ela) rouba de quem a conduz.
// Goleiro rouba encostando na hitbox (e fica com a bola na mão). Bola na mão não é roubada.
function trySteal(b, owner, ops) {
  if (tick < b.protectUntil) return false;
  let best = null, bestD = Infinity;
  for (const q of playerById.values()) {
    if (q.id === owner.id) continue;
    const qs = players.get(q.id);
    if (!qs || qs.inactive || qs.dim !== ops.dim) continue;
    if (tick < (b.noPickup[q.id] || 0)) continue;
    const dx = qs.x - b.x, dz = qs.z - b.z;
    const d2 = dx * dx + dz * dz;
    const touch = qs.keeper ? touchesKeeper(b, qs) : touchesHitbox(b, qs);
    if (touch && d2 < bestD) { bestD = d2; best = q; }
  }
  if (!best) return false;
  const qs = players.get(best.id);
  b.noPickup[owner.id] = tick + C.STEAL_PROTECT;
  if (qs.keeper) grabToHand(b, best, qs, true);
  else takeBall(b, best, qs);
  b.protectUntil = tick + C.STEAL_PROTECT;
  try { best.onScreenDisplay.setActionBar("§a⚽ Você roubou a bola!"); } catch {}
  try { owner.onScreenDisplay.setActionBar("§c⚽ Roubaram a sua bola!"); } catch {}
  try { world.sendMessage("§e⚽ " + best.name + " roubou a bola de " + owner.name + "!"); } catch {}
  sound(b.dim, qs.x, qs.y, qs.z, "random.orb", 0.8, 1.0);
  return true;
}

// ---------------------------------- Posse ---------------------------------
// Bola parada no chão (rolando bem devagar ou em repouso, apoiada num bloco).
function isGroundBall(b) {
  if (!(b.resting || Math.hypot(b.vx, b.vy, b.vz) < C.DIRECT_KICK_MAX_BALL_SPEED)) return false;
  return solidAt(b.dim, Math.floor(b.x), Math.floor(b.y - R - 0.05), Math.floor(b.z));
}

// Domínio: encostou em qualquer parte da hitbox do jogador. Chegou PULANDO numa bola parada no chão = chute direto.
function tryPickup(b) {
  let best = null, bestD = Infinity;
  for (const p of playerById.values()) {
    const ps = players.get(p.id);
    if (!ps || ps.inactive || ps.dim !== b.dim.id) continue;
    if (tick < (b.noPickup[p.id] || 0)) continue;
    if (b.clearOf === p.id) { if (touchesHitbox(b, ps)) continue; b.clearOf = null; }   // acabou de soltar: saia de cima
    if (ps.keeper) {                                  // goleiro: só se encostar na hitbox
      if (touchesKeeper(b, ps) && !(bestD < 0)) { best = p; bestD = -1; }
      continue;
    }
    if (!touchesHitbox(b, ps)) continue;
    const dx = ps.x - b.x, dz = ps.z - b.z;
    const d2 = dx * dx + dz * dz;
    if (d2 < bestD) { bestD = d2; best = p; }
  }
  if (best) {
    const bs = players.get(best.id);
    if (bs.keeper) grabToHand(b, best, bs);
    else if (!bs.onGround && isGroundBall(b)) kick(b, best, bs);   // chute direto
    else takeBall(b, best, bs);
  }
}

// ---------------------------------- Física --------------------------------
function physics(b) {
  const dim = b.dim;
  if (b.resting && tick % 10 !== 0) return;   // bola parada: só revalida o chão a cada 0,5 s
  b.resting = false;

  b.vy -= C.GRAVITY;
  b.vx *= C.AIR_DRAG; b.vz *= C.AIR_DRAG; b.vy *= C.AIR_DRAG;
  const sp = Math.hypot(b.vx, b.vy, b.vz);
  if (sp > C.MAX_BALL_SPEED) {
    const k = C.MAX_BALL_SPEED / sp;
    b.vx *= k; b.vy *= k; b.vz *= k;
  }

  for (let g = 0; g < 6 && collides(dim, b.x, b.y, b.z); g++) b.y += 0.5; // nasceu dentro de bloco

  const maxc = Math.max(Math.abs(b.vx), Math.abs(b.vy), Math.abs(b.vz));
  const n = Math.max(1, Math.ceil(maxc / 0.3));   // sub-passos: nunca atravessa paredes
  let rolling = false;
  for (let i = 0; i < n; i++) {
    if (moveAxis(dim, b, "x", b.vx / n)) {
      const imp = Math.abs(b.vx);
      b.vx = Math.abs(b.vx) < 0.02 ? 0 : -b.vx * C.WALL_BOUNCE;
      if (imp > 0.25) sound(dim, b.x, b.y, b.z, "mob.slime.small", 0.5, 1.2);
      checkGoal(b);
    }
    if (moveAxis(dim, b, "z", b.vz / n)) {
      const imp = Math.abs(b.vz);
      b.vz = Math.abs(b.vz) < 0.02 ? 0 : -b.vz * C.WALL_BOUNCE;
      if (imp > 0.25) sound(dim, b.x, b.y, b.z, "mob.slime.small", 0.5, 1.2);
      checkGoal(b);
    }
    if (moveAxis(dim, b, "y", b.vy / n)) {
      checkGoal(b);
      if (b.vy < 0) {
        const impact = -b.vy;
        if (impact > C.BOUNCE_MIN_IMPACT) {
          b.vy = impact * C.BOUNCE_STRENGTH;
          b.vx *= C.BOUNCE_HORIZONTAL_KEEP; b.vz *= C.BOUNCE_HORIZONTAL_KEEP;
          if (impact > 0.25) sound(dim, b.x, b.y, b.z, "mob.slime.small", Math.min(1, impact), 0.9);
        } else {
          b.vy = 0;
          rolling = true;
        }
      } else {
        b.vy = -b.vy * 0.3; // bateu no teto
      }
    }
  }

  if (rolling) {            // rolando no chão: atrito
    const hs = Math.hypot(b.vx, b.vz);
    const ns = hs * C.GROUND_FRICTION - C.GROUND_STOP_DECEL;
    if (ns <= 0.004) { b.vx = 0; b.vz = 0; }
    else { b.vx *= ns / hs; b.vz *= ns / hs; }
    if (b.vx === 0 && b.vz === 0) b.resting = true;
    b.safe.x = b.x; b.safe.y = b.y; b.safe.z = b.z;
  }

  if (b.y < -70) {          // caiu no void: volta para o último ponto seguro
    b.x = b.safe.x; b.y = b.safe.y; b.z = b.safe.z;
    b.vx = b.vy = b.vz = 0;
  }

  const hs = Math.hypot(b.vx, b.vz);
  if (hs > 0.03) b.yaw = Math.atan2(-b.vx, b.vz) / DEG;
  b.dirty = true;
}

function syncEntity(b) {
  b.entity.teleport({ x: b.x, y: b.y - R, z: b.z }, { rotation: { x: 0, y: b.yaw } });
  b.dirty = false;
}

function stepBall(b) {
  const e = b.entity;
  if (!isValid(e)) { balls.delete(b.id); return; }
  try {
    let owner = b.ownerId ? playerById.get(b.ownerId) : null;
    let ops = owner ? players.get(owner.id) : null;
    if (b.ownerId && (!owner || !ops || ops.dim !== b.dim.id || ops.inactive)) {
      release(b);          // dono saiu, morreu ou mudou de dimensão
      owner = null; ops = null;
    }
    if (b.mk) {
      holdByMob(b);                          // segurada pelo goleiro (mob)
    } else if (owner) {
      b.lastPlayer = owner.name;
      if (ops.sneakEdge) {
        if (b.held && ops.keeper) {          // goleiro: agachar solta a bola no chão
          b.held = false;
          b.protectUntil = tick + C.PICKUP_PROTECT;
          try { owner.onScreenDisplay.setActionBar("§a⚽ Bola no chão! §7Pule para chutar."); } catch {}
          dribble(b, owner, ops, true);
        } else if (b.held) {                 // jogador: agachar arremessa o lateral
          throwIn(b, owner, ops);
        } else {                             // agachar com a bola nos pés: pega na mão
          b.held = true;
          try { owner.onScreenDisplay.setActionBar("§e⚽ Bola na mão! §7Toque num bloco: colocar | Agache: arremessar"); } catch {}
          hold(b, owner, ops);
        }
      } else if (b.held) {
        if (ops.keeper && ops.kick) kick(b, owner, ops);   // goleiro chuta pulando
        else hold(b, owner, ops);                           // na mão: sem roubo
      } else if (ops.kick) kick(b, owner, ops);
      else if (!trySteal(b, owner, ops)) dribble(b, owner, ops, false);
    } else {
      physics(b);
      tryPickup(b);
    }
    if (!b.mk && !b.held) { tryMobKeepers(b); if (!b.mk) checkOut(b); }
    if (b.dirty) { checkGoal(b); syncEntity(b); }
    b.px = b.x; b.py = b.y; b.pz = b.z;
    if (tick % 10 === 0) {                     // bola é "invencível": restaura a vida
      const h = e.getComponent("minecraft:health");
      if (h) h.resetToMaxValue();
    }
  } catch (err) {
    logOnce(err);
    if (!isValid(e)) balls.delete(b.id);
  }
}

// ------------------------------- Gol --------------------------------------
// Bola encostou (em cima, nos lados ou embaixo) num bloco de gol -> aviso na tela de TODOS.
const GOAL_BLOCKS = { "football:goal_home": "home", "football:goal_away": "away" };

function announceGoal(b, kind) {
  b.goalCooldown = tick + C.GOAL_COOLDOWN;
  const counted = S.counting && S.match.state !== "finished";
  if (counted) {                                   // contagem de gols ligada no cronômetro
    if (kind === "home") S.home++; else S.away++;
    S.history.push({ k: kind, p: b.lastPlayer || "" });
    if (S.history.length > 100) S.history.shift();
    markDirty(); updateHud(true); updateScoreBlocks();
  }
  const title = kind === "home" ? "§l§bGOL DE CASA" : "§l§cGOL DE FORA";
  let sub;
  if (counted) sub = "§bCASA " + S.home + " §fx §c" + S.away + " FORA";
  else if (b.lastPlayer) sub = "§fÚltimo toque: §e" + b.lastPlayer;
  titleAll(title, sub, "random.levelup");
  if (counted) {
    try {
      world.sendMessage("§e⚽ " + (kind === "home" ? "Gol de CASA" : "Gol de FORA") +
        (b.lastPlayer ? " §7(último toque: " + b.lastPlayer + ")" : "") +
        " §7| §bCASA " + S.home + " §fx §c" + S.away + " FORA");
    } catch {}
  }
}

function checkGoal(b) {
  if (tick < b.goalCooldown) return;
  const m = R + 0.08;   // margem: conta como "encostar"
  const x0 = Math.floor(b.x - m), x1 = Math.floor(b.x + m);
  const y0 = Math.floor(b.y - m), y1 = Math.floor(b.y + m);
  const z0 = Math.floor(b.z - m), z1 = Math.floor(b.z + m);
  for (let x = x0; x <= x1; x++)
    for (let y = y0; y <= y1; y++)
      for (let z = z0; z <= z1; z++) {
        let blk;
        try { blk = b.dim.getBlock({ x, y, z }); } catch { continue; }
        const kind = blk ? GOAL_BLOCKS[blk.typeId] : undefined;
        if (kind) { announceGoal(b, kind); return; }
      }
}

// ======================= CRONÔMETRO, PLACAR E HUD ===========================
const S = {
  home: 0, away: 0, history: [], counting: false,
  match: { state: "idle", dur: 0, extra: 0, elapsed: 0 },   // state: idle|running|paused|halted|finished
  ballP: 0, ballS: 1,                                        // cores da bola (índices): principal / secundária
};
let outBlocks = [];              // blocos "Bola Fora": { d, x, y, z, fx, fz, miss }
let outDirty = false;
let scoreBlocks = [];            // blocos de placar registrados: { d, x, y, z, k, miss }
let stateLoaded = false, stateDirty = false, blocksDirty = false;
let hudKey = "", hudOn = false, hudCleared = false;
const OBJ_ID = "football_hud";
const SCORE_BLOCKS = { "football:scoreboard_home": "home", "football:scoreboard_away": "away" };

function markDirty() { stateDirty = true; }

function saveState() {
  if (!stateLoaded) return;
  try {
    if (stateDirty) { world.setDynamicProperty("football:state", JSON.stringify(S)); stateDirty = false; }
    if (blocksDirty) { world.setDynamicProperty("football:blocks", JSON.stringify(scoreBlocks)); blocksDirty = false; }
    if (outDirty) { world.setDynamicProperty("football:outblocks", JSON.stringify(outBlocks)); outDirty = false; }
  } catch (err) { logOnce(err); }
}

function loadState(attempt) {
  try {
    const raw = world.getDynamicProperty("football:state");
    if (typeof raw === "string") {
      const o = JSON.parse(raw);
      S.home = o.home | 0; S.away = o.away | 0; S.counting = !!o.counting;
      S.history = Array.isArray(o.history) ? o.history.slice(-100) : [];
      if (o.match) Object.assign(S.match, o.match);
      if (S.match.state === "running") S.match.state = "paused";   // mundo reaberto: volta pausado
      if (Number.isInteger(o.ballP) && o.ballP >= 0 && o.ballP < 12) S.ballP = o.ballP;
      if (Number.isInteger(o.ballS) && o.ballS >= 0 && o.ballS < 12) S.ballS = o.ballS;
    }
    const ro = world.getDynamicProperty("football:outblocks");
    if (typeof ro === "string") { const a = JSON.parse(ro); if (Array.isArray(a)) outBlocks = a; }
    const rb = world.getDynamicProperty("football:blocks");
    if (typeof rb === "string") { const a = JSON.parse(rb); if (Array.isArray(a)) scoreBlocks = a; }
    stateLoaded = true; hudKey = ""; hudCleared = false;
    for (const b of balls.values()) colorNewBall(b.entity);
  } catch (err) {
    if ((attempt || 0) < 10) system.runTimeout(() => loadState((attempt || 0) + 1), 20);
    else { logOnce(err); stateLoaded = true; }
  }
}
system.run(() => loadState(0));

// ------------------------------ Textos / avisos ---------------------------
function fmt(sec) { const m = Math.floor(sec / 60), r = sec % 60; return m + ":" + (r < 10 ? "0" : "") + r; }

function clockText() {
  const M = S.match, sec = Math.floor(M.elapsed / 20);
  if (M.elapsed < M.dur * 1200) return fmt(sec);
  return fmt(M.dur * 60) + " +" + fmt(sec - M.dur * 60);
}

function titleAll(title, subtitle, snd) {
  const opts = { fadeInDuration: 5, stayDuration: 60, fadeOutDuration: 20 };
  if (subtitle) opts.subtitle = subtitle;
  for (const p of world.getAllPlayers()) {
    try {
      p.onScreenDisplay.setTitle(title, opts);
      if (snd) p.playSound(snd, { volume: 1, pitch: 1 });
    } catch (err) { logOnce(err); }
  }
}

// -------------------------- Placar no canto da tela -----------------------
// Usa o painel lateral (sidebar) do scoreboard: canto direito da tela de TODOS os jogadores.
function hudTitle() {
  const M = S.match;
  if (M.state === "idle") return "§l§eFUTEBOL";
  if (M.state === "finished") return "§l§eFIM DE JOGO";
  let t = "§l§e" + clockText();
  if (M.extra > 0) t += " §6(+" + M.extra + ")";
  if (M.state === "halted") t += " §7[FIM DO TEMPO]";
  else if (M.state === "paused") t += " §7[PAUSADO]";
  return t;
}

function updateHud(force) {
  const show = S.counting || S.match.state !== "idle";
  try {
    const sb = world.scoreboard;
    if (!show) {
      if (hudOn || !hudCleared) {
        sb.clearObjectiveAtDisplaySlot(DisplaySlotId.Sidebar);
        if (sb.getObjective(OBJ_ID)) sb.removeObjective(OBJ_ID);
        hudOn = false; hudCleared = true; hudKey = "";
      }
      return;
    }
    const title = hudTitle();
    const key = title + "|" + S.home + "|" + S.away;
    if (!force && hudOn && key === hudKey) return;
    hudKey = key;
    if (sb.getObjective(OBJ_ID)) sb.removeObjective(OBJ_ID);
    const obj = sb.addObjective(OBJ_ID, title);
    obj.setScore("§bCASA", S.home);
    obj.setScore("§cFORA", S.away);
    sb.setObjectiveAtDisplaySlot(DisplaySlotId.Sidebar, { objective: obj, sortOrder: ObjectiveSortOrder.Descending });
    hudOn = true; hudCleared = false;
  } catch (err) { logOnce(err); }
}

// ------------------------------ Partida -----------------------------------
function startMatch(min) {
  const M = S.match;
  M.state = "running"; M.dur = min; M.extra = 0; M.elapsed = 0;
  S.counting = true;                 // a contagem de gols começa junto com a partida
  markDirty(); updateHud(true); updateScoreBlocks();
  titleAll("§l§aCOMEÇOU A PARTIDA", "§fDuração: §e" + min + " min", "note.pling");
}

function finishMatch() {
  S.match.state = "finished";
  const sub = (S.counting || S.home + S.away > 0) ? "§bCASA " + S.home + " §fx §c" + S.away + " FORA" : undefined;
  titleAll("§l§eFIM DE JOGO", sub, "note.bell");
  markDirty(); updateHud(true);
}

function addExtra(n) {
  const M = S.match;
  M.extra += n;
  if (M.state === "halted") M.state = "running";     // tempo regulamentar tinha acabado: volta a correr
  titleAll("§l§6ACRÉSCIMOS: +" + n + " MIN", "§fTotal de acréscimos: §e" + M.extra + " min", "note.pling");
  markDirty(); updateHud(true);
}

function matchStep() {
  const M = S.match;
  if (M.state !== "running") return;
  M.elapsed++;
  const reg = M.dur * 1200, end = (M.dur + M.extra) * 1200;
  if (M.elapsed >= end) {
    M.elapsed = end;
    if (M.extra === 0) {         // acabou o tempo sem acréscimos: espera decisão (acréscimos ou encerrar)
      M.state = "halted";
      titleAll("§l§eFIM DO TEMPO", "§fAdicione acréscimos ou encerre a partida", "note.bell");
      markDirty(); updateHud(true);
    } else finishMatch();
    return;
  }
  if (M.elapsed === reg && M.extra > 0) {
    titleAll("§l§6ACRÉSCIMOS", "§f+" + M.extra + " minuto(s)", "note.pling");
  }
  if (M.elapsed % 20 === 0) markDirty();
}

// ---------------------------- Blocos de placar ----------------------------
function registerScoreBlock(block, kind) {
  const d = block.dimension.id, l = block.location;
  for (const r of scoreBlocks) if (r.d === d && r.x === l.x && r.y === l.y && r.z === l.z) { r.k = kind; return; }
  scoreBlocks.push({ d, x: l.x, y: l.y, z: l.z, k: kind, miss: 0 });
  blocksDirty = true;
}

function unregisterScoreBlock(block) {
  const d = block.dimension.id, l = block.location;
  const n = scoreBlocks.length;
  scoreBlocks = scoreBlocks.filter((r) => !(r.d === d && r.x === l.x && r.y === l.y && r.z === l.z));
  if (scoreBlocks.length !== n) blocksDirty = true;
}

// Atualiza o dígito (0-9) de todos os blocos de placar conforme os gols contados.
function updateScoreBlocks() {
  if (scoreBlocks.length === 0) return;
  const keep = [];
  let changed = false;
  for (const r of scoreBlocks) {
    let blk;
    try { blk = world.getDimension(r.d).getBlock({ x: r.x, y: r.y, z: r.z }); } catch { keep.push(r); continue; }
    if (!blk) { keep.push(r); continue; }                 // chunk descarregado: tenta depois
    let id;
    try { id = blk.typeId; } catch { keep.push(r); continue; }
    if (SCORE_BLOCKS[id] !== r.k) {                       // bloco foi quebrado/trocado
      r.miss = (r.miss || 0) + 1;
      if (r.miss >= 3) { changed = true; continue; }
      keep.push(r); continue;
    }
    r.miss = 0;
    keep.push(r);
    try {
      const want = Math.min(9, r.k === "home" ? S.home : S.away);
      if (blk.permutation.getState("football:digit") !== want) {
        blk.setPermutation(blk.permutation.withState("football:digit", want));
      }
    } catch (err) { logOnce(err); }
  }
  if (changed) { scoreBlocks = keep; blocksDirty = true; }
}

if (world.afterEvents.playerPlaceBlock) {
  world.afterEvents.playerPlaceBlock.subscribe((ev) => {
    try {
      const kind = SCORE_BLOCKS[ev.block.typeId];
      if (!kind) return;
      registerScoreBlock(ev.block, kind);
      system.run(updateScoreBlocks);
    } catch (err) { logOnce(err); }
  });
}
if (world.afterEvents.playerBreakBlock) {
  world.afterEvents.playerBreakBlock.subscribe((ev) => {
    try {
      const id = ev.brokenBlockPermutation.type.id;
      if (SCORE_BLOCKS[id]) unregisterScoreBlock(ev.block);
    } catch (err) { logOnce(err); }
  });
}

// ------------------------------- Menus (UI) -------------------------------
function showForm(player, form, handler, tries) {
  tries = tries || 0;
  form.show(player).then((res) => {
    if (res.canceled) {
      if (res.cancelationReason === "UserBusy" && tries < 15) {      // chat aberto etc.: tenta de novo
        system.runTimeout(() => showForm(player, form, handler, tries + 1), 10);
      }
      return;
    }
    try { handler(res); } catch (err) { logOnce(err); }
  }).catch((err) => logOnce(err));
}

function say(player, msg) {
  try { player.sendMessage(msg); } catch {}
  try { player.onScreenDisplay.setActionBar(msg); } catch {}
}

function askNumber(player, title, label, cb) {
  const f = new ModalFormData().title(title).textField(label, "ex: 12");
  showForm(player, f, (res) => {
    const n = parseInt(String((res.formValues && res.formValues[0]) || "").trim(), 10);
    if (!(n >= 1 && n <= 180)) { say(player, "§cValor inválido (use de 1 a 180)."); return; }
    cb(n);
  });
}

function startMenu(player) {
  const presets = [5, 10, 15, 20, 30, 45, 90];
  const f = new ActionFormData().title("Iniciar partida").body("§fEscolha a duração da partida:");
  for (const m of presets) f.button("§l" + m + " minutos");
  f.button("Outro valor...");
  showForm(player, f, (res) => {
    if (res.selection < presets.length) startMatch(presets[res.selection]);
    else askNumber(player, "Iniciar partida", "Duração (minutos)", (n) => startMatch(n));
  });
}

function extraMenu(player) {
  const presets = [1, 2, 3, 4, 5];
  const f = new ActionFormData().title("Acréscimos")
    .body("§fAcréscimos atuais: §e" + S.match.extra + " min\n§7Quantos minutos adicionar?");
  for (const m of presets) f.button("§l+" + m + " min");
  f.button("Outro valor...");
  showForm(player, f, (res) => {
    if (res.selection < presets.length) addExtra(presets[res.selection]);
    else askNumber(player, "Acréscimos", "Minutos a adicionar", (n) => addExtra(n));
  });
}

function confirmMenu(player, text, yesLabel, fn) {
  const f = new ActionFormData().title("Confirmar").body(text).button("§c" + yesLabel).button("Cancelar");
  showForm(player, f, (res) => { if (res.selection === 0) fn(); });
}

function openMenu(player) {
  const M = S.match;
  const stateLabel = { idle: "sem partida", running: "em andamento", paused: "pausada", halted: "fim do tempo (aguardando)", finished: "encerrada" }[M.state];
  let body = "§fPartida: §e" + stateLabel;
  if (M.state !== "idle") {
    body += "\n§fTempo: §e" + clockText() + " §7/ " + M.dur + " min";
    if (M.extra > 0) body += " §6(+" + M.extra + " min de acréscimos)";
  }
  body += "\n§fGols: §bCASA " + S.home + " §fx §c" + S.away + " FORA";
  body += "\n§fContagem de gols: " + (S.counting ? "§aligada" : "§7desligada");

  const f = new ActionFormData().title("Cronômetro e Placar").body(body);
  const acts = [];
  const add = (label, fn) => { f.button(label); acts.push(fn); };

  if (M.state === "idle" || M.state === "finished") add("§2Iniciar partida", () => startMenu(player));
  if (M.state === "running") add("§6Pausar cronômetro", () => { M.state = "paused"; markDirty(); updateHud(true); say(player, "§6Cronômetro pausado."); });
  if (M.state === "paused") add("§2Retomar cronômetro", () => { M.state = "running"; markDirty(); updateHud(true); say(player, "§aCronômetro retomado."); });
  if (M.state === "running" || M.state === "paused" || M.state === "halted") {
    add("§1Adicionar acréscimos", () => extraMenu(player));
    add("§4Encerrar partida", () => confirmMenu(player, "§fEncerrar a partida agora?", "Sim, encerrar", () => finishMatch()));
  }
  add(S.counting ? "§6Parar contagem de gols" : "§2Começar contagem de gols", () => {
    S.counting = !S.counting; markDirty(); updateHud(true); updateScoreBlocks();
    say(player, S.counting ? "§aContagem de gols iniciada." : "§6Contagem de gols parada.");
  });
  if (S.history.length > 0) {
    add("§eAnular último gol", () => {
      const g = S.history.pop();
      if (!g) return;
      if (g.k === "home") S.home = Math.max(0, S.home - 1); else S.away = Math.max(0, S.away - 1);
      markDirty(); updateHud(true); updateScoreBlocks();
      const who = g.k === "home" ? "CASA" : "FORA";
      world.sendMessage("§e⚽ Último gol anulado (" + who + "). §7| §bCASA " + S.home + " §fx §c" + S.away + " FORA");
    });
  }
  add("Cor da bola", () => ballColorMenu(player));
  add("§4Resetar gols", () => confirmMenu(player, "§fZerar o placar (CASA e FORA)?", "Sim, resetar", () => {
    S.home = 0; S.away = 0; S.history = [];
    markDirty(); updateHud(true); updateScoreBlocks();
    world.sendMessage("§e⚽ Placar resetado: §bCASA 0 §fx §c0 FORA");
  }));

  showForm(player, f, (res) => { const fn = acts[res.selection]; if (fn) fn(); });
}

// itemUseOn foi removido no @minecraft/server 2.0. playerInteractWithBlock é o substituto;
// este adaptador mantém o formato { itemStack, source } que os handlers já usam.
function onItemUseOnBlock(handler) {
  world.afterEvents.playerInteractWithBlock.subscribe((ev) => {
    handler({ itemStack: ev.itemStack, source: ev.player, block: ev.block });
  });
}

// Item Cronômetro: usar abre o menu.
const lastMenu = new Map();
function onStopwatchUse(ev) {
  try {
    if (!ev.itemStack || ev.itemStack.typeId !== "football:stopwatch") return;
    const p = ev.source;
    if (!p) return;
    if (tick - (lastMenu.get(p.id) ?? -100) < 10) return;     // evita abrir 2x (itemUse + itemUseOn)
    lastMenu.set(p.id, tick);
    openMenu(p);
  } catch (err) { logOnce(err); }
}
world.afterEvents.itemUse.subscribe(onStopwatchUse);
onItemUseOnBlock(onStopwatchUse);

// ============================ GOLEIRO (MOB) =================================
// Anda só de LADO (perpendicular ao lado que ele olha), inverte ao achar bloco, nunca vai pra frente.
// Bola no peito/mãos: pega e, 3 s depois, joga pra frente (força e ângulo aleatórios).
// Bola no pé: joga pra longe na hora. Clique direito nele: cor da camisa, virar, remover.
const MK_TYPE = "football:goalkeeper";
const mobKeepers = new Map();     // id da entidade -> estado do goleiro
const SHIRT_NAMES = ["Amarelo", "Vermelho", "Azul", "Verde", "Preto", "Branco", "Laranja", "Roxo", "Rosa", "Ciano", "Cinza", "Marrom"];

function snap90(deg) { const r = Math.round(deg / 90) * 90; return ((r + 180) % 360 + 360) % 360 - 180; }

function registerMobKeeper(e) {
  const old = mobKeepers.get(e.id);
  if (old) { if (!isValid(old.entity)) old.entity = e; old.dim = e.dimension; return old; }
  const loc = e.location;
  let yaw = null, dir = 1;
  try { const y = e.getDynamicProperty("football:yaw"); if (typeof y === "number") yaw = y; } catch {}
  try { const d = e.getDynamicProperty("football:dir"); dir = (d === 1 || d === -1) ? d : (Math.random() < 0.5 ? -1 : 1); } catch {}
  if (yaw === null) {          // recém-criado: vira para o jogador mais próximo (alinhado a 90°)
    let best = null, bd = 16 * 16;
    for (const p of playerById.values()) {
      try {
        if (p.dimension.id !== e.dimension.id) continue;
        const dx = p.location.x - loc.x, dz = p.location.z - loc.z, d2 = dx * dx + dz * dz;
        if (d2 < bd) { bd = d2; best = { dx, dz }; }
      } catch {}
    }
    if (best) yaw = snap90(Math.atan2(-best.dx, best.dz) / DEG);
    else { let ry = 0; try { ry = e.getRotation().y; } catch {} yaw = snap90(ry); }
    try { e.setDynamicProperty("football:yaw", yaw); } catch {}
  }
  let speed = C.MK_SPEED;
  try { const sp = e.getDynamicProperty("football:speed"); if (typeof sp === "number" && sp > 0) speed = sp; } catch {}
  const k = { id: e.id, entity: e, dim: e.dimension, yaw, dir, speed, state: "patrol", holdUntil: 0, ball: null };
  mobKeepers.set(e.id, k);
  return k;
}

function scanMobKeepers() {
  const dims = new Map();
  for (const p of playerById.values()) {
    try { dims.set(p.dimension.id, p.dimension); } catch {}
  }
  for (const d of dims.values()) {
    try { for (const e of d.getEntities({ type: MK_TYPE })) registerMobKeeper(e); } catch (err) { logOnce(err); }
  }
}

function setKeeperYaw(k, yaw) {
  k.yaw = yaw;
  try { k.entity.setDynamicProperty("football:yaw", yaw); } catch {}
}

function dropMobBall(k) {
  const b = k.ball;
  k.ball = null;
  if (b && b.mk === k.id) { b.mk = null; release(b); }
}

function stepMobKeeper(k) {
  const e = k.entity;
  if (!isValid(e)) { dropMobBall(k); mobKeepers.delete(k.id); return; }
  try {
    const dim = e.dimension;
    k.dim = dim;
    if (k.state === "hold" && (!k.ball || balls.get(k.ball.id) !== k.ball)) {   // bola sumiu (ex.: removida)
      k.ball = null; k.state = "patrol";
      try { e.triggerEvent("football:hold_off"); } catch {}
    }
    const loc = e.location;
    let nx = loc.x, nz = loc.z;
    if (k.state === "patrol") {
      const yr = k.yaw * DEG;
      const lx = Math.cos(yr), lz = Math.sin(yr);          // eixo LATERAL (perpendicular à frente)
      const step = k.speed;
      const y0 = Math.floor(loc.y + 0.05);
      const blocked = (dir) => {
        const px = Math.floor(loc.x + lx * dir * (0.32 + step)), pz = Math.floor(loc.z + lz * dir * (0.32 + step));
        return solidAt(dim, px, y0, pz) || solidAt(dim, px, y0 + 1, pz);
      };
      let move = true;
      if (blocked(k.dir)) {
        if (!blocked(-k.dir)) {                            // achou bloco: vai para o lado oposto
          k.dir = -k.dir;
          try { e.setDynamicProperty("football:dir", k.dir); } catch {}
        } else move = false;                               // preso entre dois blocos: fica parado
      }
      if (move) { nx += lx * k.dir * step; nz += lz * k.dir * step; }
    }
    e.teleport({ x: nx, y: loc.y, z: nz }, { rotation: { x: 0, y: k.yaw } });
    if (tick % 10 === 0) {                                  // invencível
      const h = e.getComponent("minecraft:health");
      if (h) h.resetToMaxValue();
    }
  } catch (err) { logOnce(err); }
}

// Altura (acima dos pés do goleiro) em que a bola tocou nele neste tick; null = não tocou.
function mobTouchHeight(b, k) {
  const loc = k.entity.location;
  const dx = b.x - b.px, dy = b.y - b.py, dz = b.z - b.pz;
  const n = Math.max(1, Math.ceil(Math.hypot(dx, dy, dz) / 0.2));
  for (let i = 1; i <= n; i++) {
    const t = i / n, x = b.px + dx * t, y = b.py + dy * t, z = b.pz + dz * t;
    if (Math.abs(x - loc.x) <= C.MK_REACH_H && Math.abs(z - loc.z) <= C.MK_REACH_H &&
        y >= loc.y - 0.3 && y <= loc.y + C.MK_REACH_UP) return y - loc.y;
  }
  return null;
}

function tryMobKeepers(b) {
  if (mobKeepers.size === 0) return;
  for (const k of mobKeepers.values()) {
    if (k.state !== "patrol" || !isValid(k.entity) || k.dim.id !== b.dim.id) continue;
    if (tick < (b.noPickup[k.id] || 0)) continue;
    let h = null;
    try { h = mobTouchHeight(b, k); } catch (err) { logOnce(err); }
    if (h === null) continue;
    if (h < C.MK_FOOT_HEIGHT) mobThrow(k, b, C.MK_FOOT_POWER_MIN, C.MK_FOOT_POWER_MAX);   // pé: joga direto
    else mobCatch(k, b);                                                                    // peito/mãos: segura
    return;
  }
}

function mobCatch(k, b) {
  release(b);
  b.mk = k.id; k.ball = b; k.state = "hold"; k.holdUntil = tick + C.MK_HOLD_TICKS;
  b.vx = b.vy = b.vz = 0; b.resting = false; b.lastPlayer = "Goleiro";
  setOwnerTag(b, "§e🧤 Goleiro");
  try { k.entity.triggerEvent("football:hold_on"); } catch {}
  sound(b.dim, b.x, b.y, b.z, "random.pop", 0.7, 1.2);
  holdByMob(b);
}

// Mantém a bola nas mãos do goleiro; passados 3 s, joga.
function holdByMob(b) {
  const k = mobKeepers.get(b.mk);
  if (!k || k.ball !== b || !isValid(k.entity)) { b.mk = null; release(b); return; }
  const loc = k.entity.location, yr = k.yaw * DEG;
  b.x = loc.x - Math.sin(yr) * C.MK_HOLD_FORWARD;
  b.y = loc.y + C.MK_HOLD_HEIGHT;
  b.z = loc.z + Math.cos(yr) * C.MK_HOLD_FORWARD;
  b.vx = b.vy = b.vz = 0; b.yaw = k.yaw; b.resting = false; b.dirty = true;
  if (tick >= k.holdUntil) mobThrow(k, b, C.MK_THROW_POWER_MIN, C.MK_THROW_POWER_MAX);
}

// Joga a bola PRA FRENTE do goleiro: força, ângulo de subida e desvio lateral aleatórios.
function mobThrow(k, b, minP, maxP) {
  const loc = k.entity.location;
  const yawR = (k.yaw + (Math.random() * 2 - 1) * C.MK_SPREAD) * DEG;
  const elev = (C.MK_ELEV_MIN + Math.random() * (C.MK_ELEV_MAX - C.MK_ELEV_MIN)) * DEG;
  const power = clamp(minP + Math.random() * (maxP - minP), 0.1, C.MAX_BALL_SPEED);
  const hx = -Math.sin(yawR), hz = Math.cos(yawR);
  b.vx = hx * Math.cos(elev) * power;
  b.vz = hz * Math.cos(elev) * power;
  b.vy = Math.sin(elev) * power;
  const fx = -Math.sin(k.yaw * DEG), fz = Math.cos(k.yaw * DEG);     // garante que sai da frente dele
  if ((b.x - loc.x) * fx + (b.z - loc.z) * fz < 0.75) {
    const nx = loc.x + fx * 0.8, nz = loc.z + fz * 0.8;
    if (!collides(b.dim, nx, b.y, nz)) { b.x = nx; b.z = nz; }
  }
  b.noPickup[k.id] = tick + C.MK_IGNORE_TICKS;
  b.mk = null; b.resting = false; b.lastPlayer = "Goleiro";
  b.yaw = Math.atan2(-hx, hz) / DEG; b.dirty = true;
  release(b);
  if (k.ball === b) {
    k.ball = null; k.state = "patrol";
    try { k.entity.triggerEvent("football:hold_off"); } catch {}
  }
  sound(b.dim, b.x, b.y, b.z, "random.pop", 0.6 + 0.4 * (power / C.MAX_BALL_SPEED), 0.6 + 0.5 * (power / C.MAX_BALL_SPEED));
}

// ---- Menu do goleiro (clique direito) ----
function colorMenu(player, e) {
  const f = new ActionFormData().title("Cor da camisa").body("§fEscolha a cor da camisa do goleiro:");
  for (const n of SHIRT_NAMES) f.button(n);
  showForm(player, f, (res) => {
    if (!isValid(e)) return;
    try { e.triggerEvent("football:shirt_" + res.selection); } catch (err) { logOnce(err); }
    say(player, "§aCamisa: " + SHIRT_NAMES[res.selection]);
  });
}

const SPEEDS = [["Muito lenta", 0.04], ["Lenta", 0.06], ["Normal", 0.09], ["Rápida", 0.13], ["Muito rápida", 0.18], ["Super rápida", 0.25]];
function speedMenu(player, e) {
  const k = mobKeepers.get(e.id) || registerMobKeeper(e);
  const f = new ActionFormData().title("Velocidade")
    .body("§fVelocidade atual: §e" + (k.speed * 20).toFixed(1) + " blocos/s\n§7Escolha a nova velocidade:");
  for (const [n, v] of SPEEDS) f.button(n + " (" + (v * 20).toFixed(1) + " b/s)");
  showForm(player, f, (res) => {
    const sel = SPEEDS[res.selection];
    if (!sel || !isValid(e)) return;
    k.speed = sel[1];
    try { e.setDynamicProperty("football:speed", sel[1]); } catch {}
    say(player, "§aVelocidade do goleiro: " + sel[0]);
  });
}

function openKeeperMenu(player, e) {
  const f = new ActionFormData().title("Goleiro").body("§fO que deseja fazer?")
    .button("Cor da camisa").button("Velocidade").button("Virar para mim").button("§4Remover goleiro");
  showForm(player, f, (res) => {
    if (!isValid(e)) return;
    if (res.selection === 0) colorMenu(player, e);
    else if (res.selection === 1) speedMenu(player, e);
    else if (res.selection === 2) {
      const k = mobKeepers.get(e.id) || registerMobKeeper(e);
      const dx = player.location.x - e.location.x, dz = player.location.z - e.location.z;
      setKeeperYaw(k, snap90(Math.atan2(-dx, dz) / DEG));
      say(player, "§aGoleiro virado para você.");
    } else if (res.selection === 3) {
      confirmMenu(player, "§fRemover este goleiro?", "Sim, remover", () => {
        const k = mobKeepers.get(e.id);
        if (k) { dropMobBall(k); mobKeepers.delete(e.id); }
        try { e.remove(); } catch (err) { logOnce(err); }
      });
    }
  });
}

const lastKeeperMenu = new Map();
function maybeOpenKeeperMenu(player, e) {
  if (!player || !e || e.typeId !== MK_TYPE) return;
  if (tick - (lastKeeperMenu.get(player.id) ?? -100) < 10) return;     // evita abrir 2x
  lastKeeperMenu.set(player.id, tick);
  openKeeperMenu(player, e);
}
// 1) clique direito no goleiro
if (world.afterEvents.playerInteractWithEntity) {
  world.afterEvents.playerInteractWithEntity.subscribe((ev) => {
    try { maybeOpenKeeperMenu(ev.player, ev.target); } catch (err) { logOnce(err); }
  });
}
// 2) bater no goleiro (alternativa caso o clique direito não funcione)
world.afterEvents.entityHitEntity.subscribe((ev) => {
  try {
    if (ev.hitEntity && ev.hitEntity.typeId === MK_TYPE && ev.damagingEntity && ev.damagingEntity.typeId === "minecraft:player") {
      maybeOpenKeeperMenu(ev.damagingEntity, ev.hitEntity);
    }
  } catch (err) { logOnce(err); }
});
// 3) Prancheta do Goleiro: usar o item olhando para o goleiro (ou perto dele) abre o menu
function onClipboardUse(ev) {
  try {
    if (!ev.itemStack || ev.itemStack.typeId !== "football:keeper_control") return;
    const p = ev.source;
    if (!p) return;
    let target = null;
    try {
      const hits = p.getEntitiesFromViewDirection({ type: MK_TYPE, maxDistance: 12 });
      if (hits && hits.length) target = hits[0].entity;
    } catch {}
    if (!target) {
      let bd = 8 * 8;
      for (const e of p.dimension.getEntities({ type: MK_TYPE, location: p.location, maxDistance: 8 })) {
        const dx = e.location.x - p.location.x, dz = e.location.z - p.location.z, d2 = dx * dx + dz * dz;
        if (d2 <= bd) { bd = d2; target = e; }
      }
    }
    if (!target) { say(p, "§cNenhum goleiro por perto. Olhe para ele e use a prancheta."); return; }
    maybeOpenKeeperMenu(p, target);
  } catch (err) { logOnce(err); }
}
world.afterEvents.itemUse.subscribe(onClipboardUse);
onItemUseOnBlock(onClipboardUse);

// ============================ COR DA BOLA ===================================
const BALL_COLOR_NAMES = ["Branco", "Preto", "Amarelo", "Vermelho", "Azul", "Verde", "Laranja", "Roxo", "Rosa", "Ciano", "Cinza", "Dourado"];

// Cada bola tem a SUA cor (guardada na própria entidade). S.ballP/S.ballS = cor das PRÓXIMAS bolas.
function applyBallColor(e, pri, sec) {
  try {
    e.triggerEvent("football:ball_primary_" + (pri ?? S.ballP));
    e.triggerEvent("football:ball_secondary_" + (sec ?? S.ballS));
  } catch (err) { logOnce(err); }
}
// Bola recém-criada (sem a tag): recebe a cor das próximas bolas, uma única vez.
function colorNewBall(e) {
  if (!stateLoaded) return;
  try {
    if (e.hasTag("fb_colored")) return;
    applyBallColor(e);
    e.addTag("fb_colored");
  } catch (err) { logOnce(err); }
}
function nearestBall(player) {
  let best = null, bd = Infinity;
  let loc;
  try { loc = player.location; } catch { return null; }
  for (const b of balls.values()) {
    if (!isValid(b.entity) || b.dim.id !== player.dimension.id) continue;
    const d = Math.hypot(b.x - loc.x, b.y - loc.y, b.z - loc.z);
    if (d < bd) { bd = d; best = b; }
  }
  return best;
}
function ballColorMenu(player) {
  const f = new ActionFormData().title("Cor da bola")
    .body("§fCor das próximas bolas: §e" + BALL_COLOR_NAMES[S.ballP] + " §fe §e" + BALL_COLOR_NAMES[S.ballS] + "\n§7Escolha a cor PRINCIPAL (fundo):");
  for (const n of BALL_COLOR_NAMES) f.button(n);
  f.button("§bPadrão (branca e preta)");
  showForm(player, f, (res) => {
    if (res.selection >= BALL_COLOR_NAMES.length) { ballTargetMenu(player, 0, 1); return; }
    const pri = res.selection;
    const f2 = new ActionFormData().title("Cor secundária")
      .body("§fPrincipal: §e" + BALL_COLOR_NAMES[pri] + "\n§7Agora a cor SECUNDÁRIA (detalhes e gomos):");
    for (const n of BALL_COLOR_NAMES) f2.button(n);
    system.runTimeout(() => showForm(player, f2, (r2) => ballTargetMenu(player, pri, r2.selection)), 5);
  });
}
function ballTargetMenu(player, pri, sec) {
  const f = new ActionFormData().title("Aplicar em quê?")
    .body("§fCores: §e" + BALL_COLOR_NAMES[pri] + " §fe §e" + BALL_COLOR_NAMES[sec])
    .button("Só nas próximas bolas criadas")
    .button("Bola mais próxima de mim")
    .button("Todas as bolas");
  system.runTimeout(() => showForm(player, f, (res) => {
    S.ballP = pri; S.ballS = sec; markDirty();                 // sempre vale para as próximas
    const name = BALL_COLOR_NAMES[pri] + " e " + BALL_COLOR_NAMES[sec];
    if (res.selection === 1) {
      const b = nearestBall(player);
      if (b) { applyBallColor(b.entity, pri, sec); try { b.entity.addTag("fb_colored"); } catch {} say(player, "§aBola mais próxima: " + name); }
      else say(player, "§cNenhuma bola por perto. §7(Próximas bolas: " + name + ")");
    } else if (res.selection === 2) {
      for (const b of balls.values()) { if (isValid(b.entity)) { applyBallColor(b.entity, pri, sec); try { b.entity.addTag("fb_colored"); } catch {} } }
      say(player, "§aTodas as bolas: " + name);
    } else say(player, "§aPróximas bolas: " + name);
  }), 5);
}

// ============================ BLOCO "BOLA FORA" =============================
// Coluna invisível (infinita pra cima): bola encostou -> volta pro chão, 1 bloco à FRENTE do bloco.
// A "frente" é o lado do jogador que colocou o bloco. O bloco só aparece (vermelho) quando alguém segura o item.
const OUT_ID = "football:out_of_bounds";
const OUT_ITEM = "football:out_of_bounds_item";
let outVisible = false;

function registerOutBlock(block, player) {
  const d = block.dimension.id, l = block.location;
  for (const r of outBlocks) if (r.d === d && r.x === l.x && r.y === l.y && r.z === l.z) return r;
  let dx = 0, dz = 1;
  try { dx = player.location.x - (l.x + 0.5); dz = player.location.z - (l.z + 0.5); } catch {}
  let fx = 0, fz = 0;
  if (Math.abs(dx) >= Math.abs(dz)) fx = dx >= 0 ? 1 : -1; else fz = dz >= 0 ? 1 : -1;
  const r = { d, x: l.x, y: l.y, z: l.z, fx, fz, miss: 0 };
  outBlocks.push(r); outDirty = true;
  return r;
}
function unregisterOutBlock(block) {
  const d = block.dimension.id, l = block.location, n = outBlocks.length;
  outBlocks = outBlocks.filter((r) => !(r.d === d && r.x === l.x && r.y === l.y && r.z === l.z));
  if (outBlocks.length !== n) outDirty = true;
}

function anyHoldingOut() {
  for (const p of playerById.values()) {
    try {
      const inv = p.getComponent("minecraft:inventory");
      const it = inv && inv.container ? inv.container.getItem(p.selectedSlotIndex) : undefined;
      if (it && it.typeId === OUT_ITEM) return true;
    } catch {}
  }
  return false;
}

// Mostra/esconde os blocos (visível só enquanto alguém segura o item) e limpa os que sumiram.
function syncOutBlocks(force) {
  if (outBlocks.length === 0) { outVisible = anyHoldingOut(); return; }
  const vis = anyHoldingOut();
  if (!force && vis === outVisible && tick % 40 !== 0) return;
  outVisible = vis;
  const keep = [];
  let changed = false;
  for (const r of outBlocks) {
    let blk;
    try { blk = world.getDimension(r.d).getBlock({ x: r.x, y: r.y, z: r.z }); } catch { keep.push(r); continue; }
    if (!blk) { keep.push(r); continue; }
    let id;
    try { id = blk.typeId; } catch { keep.push(r); continue; }
    if (id !== OUT_ID) {
      r.miss = (r.miss || 0) + 1;
      if (r.miss >= 3) { changed = true; continue; }
      keep.push(r); continue;
    }
    r.miss = 0; keep.push(r);
    try {
      const want = vis ? 1 : 0;
      if (blk.permutation.getState("football:visible") !== want) blk.setPermutation(blk.permutation.withState("football:visible", want));
    } catch (err) { logOnce(err); }
  }
  if (changed) { outBlocks = keep; outDirty = true; }
}

function checkOut(b) {
  if (outBlocks.length === 0 || tick < b.outCooldown) return;
  const did = b.dim.id, m = R + 0.08;
  for (const r of outBlocks) {
    if (r.d !== did) continue;
    if (b.x < r.x - m || b.x > r.x + 1 + m || b.z < r.z - m || b.z > r.z + 1 + m) continue;
    if (b.y < r.y - R) continue;                       // da altura do bloco para CIMA, sem limite
    placeOut(b, r);
    return;
  }
}

function placeOut(b, r) {
  b.outCooldown = tick + 20;
  const cx = r.x + r.fx, cz = r.z + r.fz;
  let yy = r.y;
  for (let i = 0; i < 4 && solidAt(b.dim, cx, yy, cz); i++) yy++;
  for (let i = 0; i < 6 && !solidAt(b.dim, cx, yy - 1, cz); i++) yy--;
  if (b.mk) {                                          // estava na mão do goleiro (mob)
    const k = mobKeepers.get(b.mk);
    if (k) k.ball = null;
    b.mk = null;
  }
  release(b);                                          // ninguém fica com a bola
  b.x = cx + 0.5; b.z = cz + 0.5; b.y = yy + R + 0.01;
  b.px = b.x; b.py = b.y; b.pz = b.z;
  b.vx = b.vy = b.vz = 0; b.resting = false; b.dirty = true;
  b.safe.x = b.x; b.safe.y = b.y; b.safe.z = b.z;
  sound(b.dim, b.x, b.y, b.z, "random.pop", 0.7, 0.8);
  for (const p of world.getAllPlayers()) {
    try { p.onScreenDisplay.setActionBar("§e⚽ Bola fora!"); } catch {}
  }
}

if (world.afterEvents.playerPlaceBlock) {
  world.afterEvents.playerPlaceBlock.subscribe((ev) => {
    try {
      if (ev.block.typeId !== OUT_ID) return;
      registerOutBlock(ev.block, ev.player);
      system.run(() => syncOutBlocks(true));
    } catch (err) { logOnce(err); }
  });
}
if (world.afterEvents.playerBreakBlock) {
  world.afterEvents.playerBreakBlock.subscribe((ev) => {
    try { if (ev.brokenBlockPermutation.type.id === OUT_ID) unregisterOutBlock(ev.block); } catch (err) { logOnce(err); }
  });
}

// ------------------------------ Loop principal ----------------------------
system.runInterval(() => {
  tick++;
  blockCache.clear();
  updatePlayers(world.getAllPlayers());
  if (tick % 10 === 1) { scanBalls(); scanMobKeepers(); }
  for (const b of balls.values()) stepBall(b);
  for (const k of mobKeepers.values()) stepMobKeeper(k);
  if (stateLoaded) {
    matchStep();
    if (tick % 5 === 0) updateHud(false);
    if (tick % 40 === 0) updateScoreBlocks();
    if (tick % 10 === 0) syncOutBlocks(false);
    if (tick % 20 === 0 && (stateDirty || blocksDirty || outDirty)) saveState();
  }
}, 1);

world.afterEvents.entitySpawn.subscribe((ev) => {
  try { if (ev.entity.typeId === BALL_TYPE) registerBall(ev.entity); } catch {}
});

// Toque (hit) na bola: pega na mão.
world.afterEvents.entityHitEntity.subscribe((ev) => {
  try {
    const hit = ev.hitEntity, atk = ev.damagingEntity;
    if (!hit || !atk || hit.typeId !== BALL_TYPE || atk.typeId !== "minecraft:player") return;
    const b = balls.get(hit.id) || registerBall(hit);
    const ps = players.get(atk.id);
    if (!ps || ps.inactive || ps.dim !== b.dim.id) return;
    if (b.ownerId && b.ownerId !== atk.id) return;          // não tira da mão de outro
    if (Math.hypot(b.x - ps.x, b.z - ps.z) > 6) return;
    if (b.held && b.ownerId === atk.id) { placeHeldAtView(atk); return; }   // bola na mão: bater nela = colocar no chão onde mira
    if (tick < (b.noPickup[atk.id] || 0)) return;                            // acabou de soltar: não pega de volta sem querer
    grabToHand(b, atk, ps);
  } catch (err) { logOnce(err); }
});

// Clique num bloco com a bola na mão: coloca a bola ali.
if (world.afterEvents.playerInteractWithBlock) {
  world.afterEvents.playerInteractWithBlock.subscribe((ev) => {
    try {
      // No 2.0+ faceLocation é LOCAL (0..1 dentro do bloco); placeHeld espera coordenadas do mundo.
      const bl = ev.block.location, fl = ev.faceLocation;
      const world3 = fl ? { x: bl.x + fl.x, y: bl.y + fl.y, z: bl.z + fl.z } : undefined;
      placeHeld(ev.player, ev.block, ev.blockFace, world3);
    } catch (err) { logOnce(err); }
  });
}
world.afterEvents.entityHitBlock.subscribe((ev) => {
  try {
    if (ev.damagingEntity.typeId === "minecraft:player") placeHeldAtView(ev.damagingEntity, ev.hitBlock, ev.blockFace);
  } catch (err) { logOnce(err); }
});

world.afterEvents.playerLeave.subscribe((ev) => { players.delete(ev.playerId); });

world.afterEvents.playerSpawn.subscribe((ev) => {
  if (ev.initialSpawn) {
    try { ev.player.sendMessage("§a⚽ Minecraft Football 1.0 §fativo! Digite §e/scriptevent football:bola§f para criar a bola."); } catch {}
  }
});

// ----------------------- Remover bolas -------------------------------------
function removeAllBalls() {
  let n = 0;
  for (const id of ["overworld", "nether", "the_end"]) {
    try {
      for (const e of world.getDimension(id).getEntities({ type: BALL_TYPE })) {
        try { e.remove(); n++; } catch {}
      }
    } catch {}
  }
  for (const b of balls.values()) { try { b.entity.remove(); } catch {} }
  balls.clear();
  return n;
}

// Item "Removedor de Bolas": usar apaga todas as bolas do mundo.
let lastRemoveTick = -10;
function onRemoverUse(ev) {
  try {
    if (!ev.itemStack || ev.itemStack.typeId !== "football:ball_remover") return;
    if (tick - lastRemoveTick < 5) return;          // evita duplicar (itemUse + itemUseOn)
    lastRemoveTick = tick;
    const n = removeAllBalls();
    const msg = n > 0 ? "§c⚽ " + n + " bola(s) removida(s)." : "§7⚽ Nenhuma bola para remover.";
    try { ev.source.onScreenDisplay.setActionBar(msg); } catch {}
    try { ev.source.sendMessage(msg); } catch {}
  } catch (err) { logOnce(err); }
}
world.afterEvents.itemUse.subscribe(onRemoverUse);
onItemUseOnBlock(onRemoverUse);

// ----------------------- Criar bola (comando e ovo) ------------------------
let lastSpawnTick = -10;
function spawnBall(dim, src, block) {
  if (tick - lastSpawnTick < 5) return;     // evita duplicar (itemUse + itemUseOn)
  lastSpawnTick = tick;
  let x, y, z;
  if (src) {
    const l = src.location, yaw = src.getRotation().y * DEG;
    x = l.x - Math.sin(yaw) * 2; y = l.y + 0.05; z = l.z + Math.cos(yaw) * 2;
    if (collides(dim, x, y + R, z)) { x = l.x; z = l.z; }
  } else {
    const l = block.location;
    x = l.x + 0.5; y = l.y + 1.05; z = l.z + 0.5;
  }
  const e = dim.spawnEntity(BALL_TYPE, { x, y, z });
  registerBall(e);
  if (src && src.sendMessage) src.sendMessage("§a⚽ Bola criada! §fEncoste nela para dominar e pule para chutar.");
}

// Ovo da Bola: use o item (toque) para criar a bola à sua frente.
function onEggUse(ev) {
  try {
    if (ev.itemStack && ev.itemStack.typeId === "football:ball_egg") spawnBall(ev.source.dimension, ev.source);
  } catch (err) { logOnce(err); }
}
world.afterEvents.itemUse.subscribe(onEggUse);
onItemUseOnBlock(onEggUse);

// ------------------------------- Comandos ---------------------------------
//  /scriptevent football:bola     -> cria a bola à sua frente (remove a anterior)
//  /scriptevent football:remover  -> remove todas as bolas
//  /give @s football:ball_egg     -> entrega o Ovo da Bola
//  /give @s football:ball_remover -> entrega o Removedor de Bolas (usar = apaga todas as bolas)
//  /give @s football:stopwatch    -> Cronômetro (usar abre o menu de partida, acréscimos e gols)
//  /give @s football:scoreboard_home / football:scoreboard_away -> blocos de placar (seguem os gols contados)
//  Domínio: encostar em qualquer parte do corpo | Chute direto: chegar PULANDO numa bola parada no chão
//  /give @s football:out_of_bounds_item -> bloco BOLA FORA (invisível; aparece ao segurar o item). Bola encostou -> volta 1 bloco à frente dele
//  Cor da bola: menu do Cronômetro > "Cor da bola" (principal e secundária; cada bola guarda a sua cor)
//  /summon football:goalkeeper    -> goleiro (ou use o ovo de spawn); clique direito (ou bater): cor, velocidade, virar, remover
//  /give @s football:keeper_control -> Prancheta do Goleiro (usar olhando pra ele abre o menu)
//  /give @s football:goal_home    -> bloco GOL DE CASA   |   /give @s football:goal_away -> bloco GOL DE FORA
system.afterEvents.scriptEventReceive.subscribe((ev) => {
  try {
    const src = ev.sourceEntity;
    const dim = src ? src.dimension : ev.sourceBlock ? ev.sourceBlock.dimension : null;
    if (!dim) return;
    if (ev.id === "football:remover") {
      removeAllBalls();
    } else if (ev.id === "football:bola") {
      lastSpawnTick = -10;
      spawnBall(dim, src, ev.sourceBlock);
    }
  } catch (err) { logOnce(err); }
}, { namespaces: ["football"] });
